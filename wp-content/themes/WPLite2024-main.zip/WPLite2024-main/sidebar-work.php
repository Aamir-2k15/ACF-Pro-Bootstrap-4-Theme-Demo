	<div class="col-md-4">
		<?php if (is_active_sidebar('work')) : ?>
			<?php dynamic_sidebar('work'); ?>
		<?php endif; ?>
	</div>