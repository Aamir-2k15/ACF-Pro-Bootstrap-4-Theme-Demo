<?php get_header(); ?> 
<?php get_template_part('inc/not-found');?>
<?php get_footer(); ?>