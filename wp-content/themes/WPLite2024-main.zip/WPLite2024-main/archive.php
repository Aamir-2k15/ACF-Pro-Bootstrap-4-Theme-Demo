<?php get_header(); ?>
<div class="container archive">
    <h1 class="heading-lg-b"><?php wp_title(''); ?></h1>
    <?php get_template_part('inc/loop'); ?>
</div>
<?php get_footer(); ?>