<h3>Theme Features</h3>
<ol>
    <li><code>[wpl_sm help='true']:</code> For single social media</li>
    <li><code>[wpl_sm_links] </code> For All theme styled social media, can add extra class for icon like so [wpl_sm_links extra_icon_class='text-white']</li>
    <li><code>[container][/container]</code></li>
    <li><code>[row][/row]</code></li>
    <li><code>[col][/col] OR [col size='4'][/col]</code></li>
    <li>Pagination</li>
    <li><code>wpl_related_posts(): </code> For Related Posts</li>
    <li>Posts View</li>
    <li>Author Info and Author Page</li>
</ol>