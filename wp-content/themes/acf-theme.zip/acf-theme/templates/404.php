<section class="about-body other-page">
    <div class="row mb-2 mt-2 pb-4 pt-4 pb-2">
        <div class="col-md-12">
            <h3 class="pt-3 pb-2 heading-sm-b text-danger">
                <i class="fa fa-exclamation-triangle"></i> <?php _e('Sorry, Nothing found matching your serach criteria!', TD); ?>
            </h3>
            <div class="pt-5 pb-5" style="z-index: 999999 !important;position:relative;">
                <p><?php _e('Would you like to go back to <a href=" '. site_url().'">Home Page</a> ?', TD); ?></p>
                <?php //custom_serach_form(); 
                ?>
            </div>
        </div>
    </div>
</section>