<?php
$section = get_row_layout('section');
?>
<?php if (!empty($section)) : ?>
<?php endif; ?>